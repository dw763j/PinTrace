"""Continue the archived neighboring-release protocol on newly eligible responses."""

import argparse
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from typing import Any

from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version


def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


def load_archived_functions(path):
    names = {
        "_is_version_yanked", "_normalize_pkg_name", "_parse_ref_date",
        "_load_pypi_json_from_dirs", "_ordered_versions_at_cutoff", "_generate_offset_vectors",
        "_resolve_neighbor_candidates_for_task", "_extract_failed_tpl_from_ty_errors",
    }
    tree = ast.parse(path.read_text())
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in body} == names
    namespace = dict(deepcopy=deepcopy, datetime=datetime, json=json, Path=Path,
                     Any=Any, Version=Version, InvalidVersion=InvalidVersion, re=re)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def candidate_requirements(original, candidate, exact_packages):
    moves = {canonicalize_name(move["pypi_name"]): move["candidate_version"] for move in candidate["per_lib_moves"]}
    changed = {canonicalize_name(move["pypi_name"]) for move in candidate["per_lib_moves"] if move["offset"]}
    assert changed <= exact_packages, (changed, exact_packages)
    lines = []
    for line in original:
        requirement = Requirement(line)
        package = canonicalize_name(requirement.name)
        if package in moves:
            requirement.specifier = SpecifierSet("==" + moves[package])
        lines.append(str(requirement))
    assert {canonicalize_name(Requirement(line).name) for line in original} == {
        canonicalize_name(Requirement(line).name) for line in lines
    }
    return lines


def prepare_plan(row, functions, root):
    baseline_path = Path(row["neighbor_baseline"]["evidence_path"])
    baseline_record = json.loads(baseline_path.read_text())
    if isinstance(baseline_record, list):
        baseline_record = baseline_record[row["measurement_index"]]
        assert baseline_record["task_id"] == row["task_id"]
        assert baseline_record["resolver"]["status"] == "resolved"
        diagnostic = baseline_record["compat_results"]["ty"]
        assert any(error.get("rule") == "ty-install-error" for error in diagnostic["errors"])
    else:
        evaluation = baseline_record["evaluation"]
        assert evaluation["resolved"] and not evaluation["installed"]
        installation = evaluation["installation"]
        diagnostic = dict(errors=[dict(rule="ty-install-error", message=installation["stderr"] + installation["stdout"])])
    focused = functions["_extract_failed_tpl_from_ty_errors"](diagnostic, per_lib=row["neighbor_direct"])
    searchable_direct = [record for record in row["neighbor_direct"] if record["constraint_kind"] == "exact"]
    candidates, metadata = functions["_resolve_neighbor_candidates_for_task"](
        {"per_lib": searchable_direct}, neighbor_n=3, max_candidates_k=40,
        reference_date="2026-02-01T00:00:00+00:00", pypi_dirs=[root / "resources/pypi_info", root / "pypi_info"],
        specified_only=True, max_searchable_libs=12, focused_pypi_names=focused, focused_neighbor_n=10,
    )
    exact_packages = set(row["neighbor_baseline"]["model_exact_packages"])
    for candidate in candidates:
        candidate["requirements"] = candidate_requirements(row["requirements"], candidate, exact_packages)
    return {
        "request_id": row["request_id"], "model": row["model"], "task_id": row["task_id"],
        "response_sha256": row["response_sha256"], "code_sha256": sha(row["code"]),
        "file_hashes": {name: sha(code) for name, code in row["files"].items()},
        "baseline_evidence_sha256": sha(baseline_path.read_text()),
        "failed_tpl_from_ty_install_error": sorted(focused),
        "candidate_generation_meta": metadata, "generated_candidates": len(candidates),
        "candidate_scope": "model_exact_packages_only",
        "candidates": candidates,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--archived-script", type=Path, required=True)
    parser.add_argument("--reanalyze-script", type=Path, required=True)
    parser.add_argument("--osv-parent", type=Path, required=True)
    parser.add_argument("--root", type=Path, default=Path("/data/mine/llm_tpl"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    functions = load_archived_functions(args.archived_script)
    prepared = [json.loads(line) for line in args.prepared.open() if line.strip()]
    plans = [prepare_plan(row, functions, args.root) for row in prepared]
    (args.out / "candidate_plans.json").write_text(json.dumps(plans, indent=2))
    summary = {
        "responses": len(plans), "generated_candidates": sum(plan["generated_candidates"] for plan in plans),
        "all_moved_packages_have_model_exact": True, "all_package_sets_preserved": True,
        "configuration": dict(neighbor_n=3, max_candidates_k=40, max_searchable_libs=12,
                              focus_install_failed_tpl=True, focused_neighbor_n=10, specified_only=True,
                              stop_policy="first_pass", cutoff="2026-02-01T00:00:00Z", python_version="3.12"),
        "source_sha256": {str(path): sha(path.read_text()) for path in (args.prepared, args.archived_script, args.reanalyze_script)},
        "candidate_plans_sha256": sha((args.out / "candidate_plans.json").read_text()),
    }
    (args.out / "plan_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)
    if args.plan_only:
        return
    sys.path.insert(0, str(args.root))
    from evaluation_support_remote import evaluate
    spec = importlib.util.spec_from_file_location("neighbor_advisory_analysis", args.reanalyze_script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.X = args.osv_parent
    advisory_index = module.AdvisoryIndex()

    def process(row, plan):
        record = {name: value for name, value in plan.items() if name != "candidates"}
        record.update(tested_candidate_count=0, first_no_ty_install_error=None, first_ty_compatible=None,
                      first_no_ty_install_error_vulnerable=None, first_ty_compatible_vulnerable=None,
                      first_bcb_pass=None, first_bcb_pass_vulnerable=None, candidates_tested=[])
        for rank, candidate in enumerate(plan["candidates"], 1):
            signature = sha(json.dumps(candidate["per_lib_moves"], sort_keys=True))[:16]
            output = args.out / "cases" / row["request_id"] / signature
            result = evaluate(row["code"], candidate["requirements"], output, root=args.root,
                              cutoff="2026-02-01T00:00:00Z", files=row["files"],
                              primary_filename=row["primary_filename"], advisory_index=advisory_index)
            assert result["code_sha256"] == plan["code_sha256"]
            assert result["source_files"] == plan["file_hashes"]
            associations = result.get("associations", {})
            findings = [dict(pypi_name=package, version=version, is_vulnerable=bool(associations.get(package)),
                             osv_ids=associations.get(package, [])) for package, version in result.get("pins", {}).items()]
            tested = {
                **{name: candidate[name] for name in ("offset_vector", "l1_distance", "changed_lib_count", "per_lib_moves")},
                "candidate_rank": rank, "requirements": candidate["requirements"],
                "candidate_resolution": dict(status="resolved" if result["resolved"] else "failed",
                                             lock_sha256=result.get("lock_sha256")),
                "ty_compatible": result["static_pass"], "ty_install_error": not result["installed"],
                "bcb_status": "", "task_has_vuln": bool(associations), "vuln_findings": findings,
                "evaluation_path": str(output / "result.json"),
                "evaluation_sha256": sha((output / "result.json").read_text()),
            }
            record["candidates_tested"].append(tested)
            record["tested_candidate_count"] += 1
            if result["installed"] and record["first_no_ty_install_error"] is None:
                record["first_no_ty_install_error"] = tested
            if result["installed"] and associations and record["first_no_ty_install_error_vulnerable"] is None:
                record["first_no_ty_install_error_vulnerable"] = tested
            if result["static_pass"]:
                record["first_ty_compatible"] = tested
                if associations:
                    record["first_ty_compatible_vulnerable"] = tested
                break
        path = args.out / "tasks" / (row["request_id"] + ".json")
        path.parent.mkdir(exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(record, indent=2))
        temporary.replace(path)
        return record

    completed = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(process, row, plan) for row, plan in zip(prepared, plans)]
        for future in as_completed(futures):
            record = future.result()
            completed.append(record)
            print(json.dumps({"completed": len(completed), "planned": len(plans), "task_id": record["task_id"],
                              "model": record["model"], "tested": record["tested_candidate_count"],
                              "installed": record["first_no_ty_install_error"] is not None,
                              "static_pass": record["first_ty_compatible"] is not None}), flush=True)
    completed.sort(key=lambda row: row["request_id"])
    (args.out / "task_results.json").write_text(json.dumps(completed, indent=2))


if __name__ == "__main__":
    main()
