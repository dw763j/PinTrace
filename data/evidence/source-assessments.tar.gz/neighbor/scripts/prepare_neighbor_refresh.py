"""Requalify the full PinTrace VA population against corrected complete locks."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open() as source:
        for line in source:
            if line.strip():
                yield json.loads(line)


def key(row):
    return row["track"], row["mode"], row["model"].lower(), str(row["task_id"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--canonical", type=Path, required=True)
    parser.add_argument("--direct", type=Path, required=True)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--archive-audit", type=Path, required=True)
    parser.add_argument("--reanalyze-script", type=Path, required=True)
    parser.add_argument("--osv-parent", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    module_spec = importlib.util.spec_from_file_location("retained_advisory_analysis", args.reanalyze_script)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    module.X = args.osv_parent
    advisory_index = module.AdvisoryIndex()
    locks = {key(row): row for row in rows(args.canonical / "joint_locks.jsonl")}
    direct = defaultdict(list)
    for row in rows(args.direct):
        direct[key(row)].append(row)
    archived = {}
    with args.archive_audit.open(encoding="utf-8-sig") as source:
        for row in csv.DictReader(source):
            if row["eligible_under_rematch"].lower() == "true":
                archived[("d2", "inline", row["model"].lower(), row["task_id"])] = row
    assert len(archived) == 798
    decisions = []
    eligible = set()
    for task in rows(args.canonical / "task_outcomes.jsonl"):
        if task["track"] != "d2" or task["mode"] != "inline":
            continue
        task_key = key(task)
        lock = locks[task_key]
        assert task["response_sha256"] == lock["response_sha256"]
        exact = [row for row in direct[task_key] if row["constraint_kind"] == "exact" and row["resolution_origin"] == "model_exact" and row.get("resolved_version")]
        failed_install_indicator = bool(task["complete_lock"] and not task["installation_pass"])
        if failed_install_indicator:
            assert task["failure_stage"] in {
                "environment_build", "installation_failed", "venv_failed", "tool_setup_failed", "infrastructure",
            }, (task_key, task["failure_stage"])
        installation_failed = bool(task["complete_lock"] and not task["installation_pass"]
                                   and task["failure_stage"] in {"environment_build", "installation_failed"})
        matches = {}
        if installation_failed and exact:
            assert lock["joint_status"] == "resolved"
            matches = {package: list(found) for package, version in lock["pins"].items()
                       if (found := advisory_index.match(package, version))}
        qualifies = installation_failed and bool(exact) and not matches
        if qualifies:
            eligible.add(task_key)
        decisions.append({
            **{name: task[name] for name in ("track", "mode", "model", "task_id", "response_sha256")},
            "request_id": task["request_id"], "complete_lock": task["complete_lock"],
            "installation_failure": installation_failed, "model_exact_packages": sorted({row["pypi_name"] for row in exact}),
            "complete_lock_installation_false": failed_install_indicator,
            "infrastructure_excluded": failed_install_indicator and not installation_failed,
            "baseline_associations": matches, "eligible": qualifies,
            "archived_eligible": task_key in archived, "lock_path": lock["lock_path"],
            "lock_sha256": lock["lock_sha256"], "evidence_path": task["evidence_path"],
        })
    new_keys = eligible - archived.keys()
    selected = []
    selected_decisions = {key(row): row for row in decisions if key(row) in new_keys}
    for row in rows(args.prepared):
        if key(row) in new_keys:
            selected.append(dict(row, neighbor_baseline=selected_decisions[key(row)],
                                 neighbor_direct=direct[key(row)], neighbor_lock=locks[key(row)]))
    assert len(selected) == len(new_keys)
    for name, records in (("qualification", decisions), ("new_eligible_prepared", selected)):
        with (args.out / (name + ".jsonl")).open("w") as output:
            for row in records:
                output.write(json.dumps(row) + "\n")
    summary = {
        "population": "10000 PinTrace version-annotation responses",
        "population_N": len(decisions), "eligible_N": len(eligible),
        "retained_archived_N": len(eligible & archived.keys()), "new_eligible_N": len(new_keys),
        "archived_no_longer_eligible": [list(value) for value in sorted(archived.keys() - eligible)],
        "new_by_model": dict(Counter(row[2] for row in new_keys)),
        "complete_lock_install_failures_with_model_exact": sum(row["installation_failure"] and bool(row["model_exact_packages"]) for row in decisions),
        "association_exclusions": sum(bool(row["baseline_associations"]) for row in decisions),
        "complete_lock_installation_false": sum(row["complete_lock_installation_false"] for row in decisions),
        "installation_failures_checked": sum(row["installation_failure"] for row in decisions),
        "known_infrastructure_exclusions": sum(row["infrastructure_excluded"] for row in decisions),
        "advisory_counts": dict(advisory_index.counts),
        "sources": {str(path): sha(path) for path in (args.direct, args.prepared, args.archive_audit, args.reanalyze_script,
                    args.canonical / "joint_locks.jsonl", args.canonical / "task_outcomes.jsonl")},
        "eligibility": "Complete lock, installation failure, model-exact advice and no active advisory association anywhere in the baseline graph.",
    }
    (args.out / "qualification_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
