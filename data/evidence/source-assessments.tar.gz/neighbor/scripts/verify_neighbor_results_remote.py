"""Verify saved candidate outcomes against the frozen source and exact-only plans."""

from collections import Counter
import hashlib
import json
from pathlib import Path

from packaging.requirements import Requirement
from packaging.utils import canonicalize_name


ROOT = Path("/data/mine/llm_tpl/outputs/cyse_author_revision_20261112")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open() as source:
        for line in source:
            yield json.loads(line)


def main():
    prepared = {record["request_id"]: record for record in rows(ROOT / "prepared/prepared.jsonl")}
    qualification = {record["request_id"]: record for record in rows(ROOT / "neighbor/qualification.jsonl")}
    counts = Counter()
    outcomes = []
    for directory in (ROOT / "neighbor/new_search", ROOT / "neighbor/scope_correction"):
        plans = {record["request_id"]: record for record in json.loads((directory / "candidate_plans.json").read_text())}
        searches = json.loads((directory / "task_results.json").read_text())
        for search in searches:
            request_id = search["request_id"]
            source = prepared[request_id]
            plan = plans[request_id]
            exact_packages = set(qualification[request_id]["model_exact_packages"])
            assert qualification[request_id]["eligible"]
            assert source["response_sha256"] == plan["response_sha256"] == search["response_sha256"]
            assert hashlib.sha256(source["code"].encode()).hexdigest() == plan["code_sha256"]
            baseline = [Requirement(line) for line in source["requirements"]]
            for candidate in plan["candidates"]:
                alternative = [Requirement(line) for line in candidate["requirements"]]
                assert len(baseline) == len(alternative)
                for old, new in zip(baseline, alternative):
                    assert canonicalize_name(old.name) == canonicalize_name(new.name)
                    assert old.marker == new.marker and old.extras == new.extras and old.url == new.url
                    if old.specifier != new.specifier:
                        assert canonicalize_name(old.name) in exact_packages
                counts["candidate_input_checks"] += 1
            assert len(search["candidates_tested"]) == search["tested_candidate_count"]
            first_installed = None
            first_static = None
            for rank, (candidate, tested) in enumerate(zip(plan["candidates"], search["candidates_tested"]), 1):
                path = Path(tested["evaluation_path"])
                assert sha(path) == tested["evaluation_sha256"]
                actual = json.loads(path.read_text())
                assert tested["candidate_rank"] == rank
                assert actual["requirements"] == candidate["requirements"] == tested["requirements"]
                assert actual["code_sha256"] == plan["code_sha256"]
                assert actual["source_files"] == plan["file_hashes"]
                assert actual["primary_filename"] == source["primary_filename"]
                for name, expected in {"python_version": "3.12", "cutoff": "2026-02-01T00:00:00Z", "uv_version": "0.10.7", "ty_version": "0.0.23", "python_platform": "x86_64-unknown-linux-gnu"}.items():
                    assert actual[name] == expected
                assert tested["ty_compatible"] == actual["static_pass"]
                assert tested["ty_install_error"] == (not actual["installed"])
                assert tested["candidate_resolution"]["status"] == ("resolved" if actual["resolved"] else "failed")
                assert tested["task_has_vuln"] == bool(actual.get("associations"))
                if actual["installed"] and first_installed is None:
                    first_installed = rank
                if actual["static_pass"] and first_static is None:
                    first_static = rank
                    assert rank == search["tested_candidate_count"]
                counts["candidate_result_checks"] += 1
            assert (search["first_no_ty_install_error"] or {}).get("candidate_rank") == first_installed
            assert (search["first_ty_compatible"] or {}).get("candidate_rank") == first_static
            if first_static is None:
                assert search["tested_candidate_count"] == plan["generated_candidates"]
            counts["response_checks"] += 1
            outcomes.append({"request_id": request_id, "model": source["model"], "task_id": source["task_id"], "installation_rank": first_installed, "static_rank": first_static})
    report = {
        "passed": True, "counts": dict(counts), "outcomes": outcomes,
        "checks": ["Each declared evaluation hash matches its saved result.", "Every candidate preserves all generated files and direct package membership.", "Only model-exact package constraints change.", "Frozen runtime, cutoff and tool versions match the main experiment.", "First-success ranks and stopping decisions agree with raw results."],
    }
    (ROOT / "neighbor/execution_verification.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
